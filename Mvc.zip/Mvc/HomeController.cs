using Microsoft.AspNetCore.Mvc;
using Online_Pharmacy_App_MVC.Models;
using Pharmacy_DAO;
using System.Diagnostics;

namespace Online_Pharmacy_App_MVC.Controllers
{
    
    public class HomeController : Controller
    {
        private readonly HttpClient _httpClient;

        public HomeController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(User user, string userType)
        {
            if (!ModelState.IsValid)
            {
                return View(user);
            }

            HttpResponseMessage response = null;
            if (userType == "User")
            {
                response = await _httpClient.GetAsync($"http://localhost:5278/api/Users?username={user.UserName}&password={user.Password}&userType=User");
            }
            else if (userType == "Admin")
            {
                response = await _httpClient.GetAsync($"http://localhost:5278/api/Users?username={user.UserName}&password={user.Password}&userType=Admin");
            }

            if (response != null && response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ModelState.AddModelError("", "Invalid login attempt.");
            return View(user);
        }
    }
}
